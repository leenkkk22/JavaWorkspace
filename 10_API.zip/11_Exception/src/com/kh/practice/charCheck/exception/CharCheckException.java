package com.kh.practice.charCheck.exception;


public class CharCheckException extends Exception{
	
	public CharCheckException() {
		
	}
	
	public CharCheckException(String msg) {
		super(msg);
	}

}
