package com.kh.chap02_String.run;

import com.kh.chap02_String.controller.C_StringTokenizer;
import com.kh.chap02_String.controller.D_StringMethod;

public class Run {
	public static void main(String[] args) {
//		A_StringPool asp = new A_StringPool();
//		asp.method3();
//		
//		B_StringBuilderAndBuffer bsb = new B_StringBuilderAndBuffer();
//		bsb.method();
//		
		new C_StringTokenizer().method();
		
		//new D_StringMethod().method();
	}
}
