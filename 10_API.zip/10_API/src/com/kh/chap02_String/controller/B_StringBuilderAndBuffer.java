package com.kh.chap02_String.controller;

public class B_StringBuilderAndBuffer {
	/*
	 * StringBuilder and StringBuffer
	 *  - 문자열 기반 가변 클래스
	 *  - 문자열의 메모리 부족 이슈를 해결하기 위해 만들어진 클래스
	 *  - 두 클래스의 사용 방법은 동일하다.
	 *  - 차이점: "동기화" 여부
	 *  - StringBuilder는 동기화를 지원하지 않기 때문에 "멀티스레드환경"에서 좋은 성능을 보인다.
	 *  - StringBuffer는 동기화를 지원하기 때문에 '멀티스레드환경'에서 스레드 안전성을 보장할 수 있지만
	 *    성능이 좋지 못하다.
	 * */
	
	public void method() {
		String str = "Hello";
		str += "World";
		
		StringBuilder sb1 = new StringBuilder("hello"); // java.lang에서 자동 import
		sb1.append("World"); // 같은 저장 공간에서 이어쓰기 가능
		sb1.append("!!!"); // 몇개를 작성하든 주소값은 한 개 *메모리 효율 상승*
		StringBuffer sb2 = new StringBuffer("hello");
		sb2.append("World!"); // 이름에 마우스 갖다대면 시계 아이콘 = 동기화 여부
		
		
		System.out.println(sb1); // 참조 자료형이다
		System.out.println(sb2); //toString() 오버라이딩
		
		System.out.println("문자열의 길이는 ? "+sb1.length());
		System.out.println("문자열에서 o의 마지막 위치는 ? " + sb1.lastIndexOf("o"));
		//0번 인덱스부터 문자를 삭제.
		
		System.out.println("모든 글자 삭제: " + sb1.delete(0, sb1.length()-1));
		//특정 위치의 문자를 삭제.
		
		System.out.println("마지막 위치의 문자 삭제하기 : " + sb1.deleteCharAt(sb1.length()-1)); // 바로 위 delete 주석처리 하면 나옴
		
		
		
	}

}
