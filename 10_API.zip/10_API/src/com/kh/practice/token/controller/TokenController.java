package com.kh.practice.token.controller;

import java.util.StringTokenizer;

public class TokenController {
	
	public TokenController() {
		
	}
	
	public String afterToken(String str) {
		
		// 방법 1. replace
//		System.out.println(str.replace(" ", ""));
		// 방법 2. split
//		String[] arr = str.split(" "); // [j,a,v,a..]
//		String result = "";
//		for(String s : arr) {
//			result += s;
//		}
		
		//방법 3. StringTokenizer 이용
		str.trim();
		StringTokenizer stn = new StringTokenizer(str, " ");
		String result = "";
		while(stn.hasMoreTokens()) {
			// result += stn.nextToken());  더 짧게 실행ㅎ 가능함
			result = result.concat(stn.nextToken());
			
	}
		return result;
	}
	
	public String firstCap(String input) {
		// 매개변수로 받아온 input의 첫 번째 글자만 대문자로 바꾼 문자열 반환
		//String first = input.substring(0,1).toUpperCase();
		
		String result = input.toUpperCase();
		String s = result.substring(0, 1);
		String p = result.substring(1);
		p = p.toLowerCase();
		s = s.concat(p);
		
		return s;		
	}
	
	public int findChar(String input, char one) {
		// 매개변수의 문자가 문자열 안에 몇 개가 들어가 있는지 반환
		
		//Easy
//		char[] arr = input.toCharArray();
//		
//		for(char ch : arr) {
//			if(ch == one) {
//				count++;
//			}
//		}
		
		int count = 0;
		for(int i = 0; i<input.length(); i++) {
			if(one == input.charAt(i)) {	
				count++;
			}
			
			
		}
		
		return count;
		
	}

}
