package com.kh.practice.leap.controller;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class LeapController {
	
	public boolean isLeapYear(int year) {
		boolean leap = true;
		
			if(year / 4 == 0 && (!(year / 100 ==0 || year / 400 == 0))) {
				leap = true;
			} else leap = false;
			return leap;
		}
		

	
	public long leapDate(Calendar c) {
		GregorianCalendar today = new GregorianCalendar();
		int year = today.get(Calendar.YEAR);
		int day = 0;
		for (int i = 0; i<year; i++) {
			boolean leap = isLeapYear(i);
			if(leap = true) {
				day += 366;
			}else { 
				day += 365;
			}
			
		}
		
		
	}

}
