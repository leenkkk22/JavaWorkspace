package com.kh.practice.leap.view;

import java.util.Calendar;
import java.util.GregorianCalendar;

import com.kh.practice.leap.controller.LeapController;

public class LeapView {
	LeapController lc = new LeapController();
	public LeapView() {

		
		//boolean leap = lc.isLeapYear(year);
		
		
		System.out.println(result);
		
	}
}
