package com.kh.practice.file.controller;

import com.kh.practice.file.model.dao.FileDAO;

public class FileController {
	private FileDAO fd = new FileDAO();
	
	

	public boolean checkName(String file) {
		boolean d = fd.checkName(file);
		
		return d;
	}
	
	public void fileSave(String file, StringBuilder sb) {
		String str = sb.toString();
		
		fd.fileSave(file, str);
		
	}
	
	public StringBuilder fileOpen(String file) {
		fd.fileOpen(file);
		
		
	}
	
	public void fileEdit(String file, StringBuilder sb) {
		
	}
	
	
}
