package com.kh.practice.file.model.dao;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

// OOP 프로그래밍 상 메뉴에서 DAO로 곧바로 접근하진 않는다. 
// Menu -> Controller -> DAO 식으로 호출해서 작성
public class FileDAO {
	FileWriter fw = null;
	public boolean checkName(String file) {
		fileEdit(file);
		
		boolean check = true;
		return check; // xxx
	}
	
	public void fileSave(String file, String s) {
		File file1 = new File(file);
		try {
			fw = new FileWriter(s);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	public StringBuilder fileOpen (String file){
		
	}
	
	public void fileEdit(String file) {
		
	}

}
