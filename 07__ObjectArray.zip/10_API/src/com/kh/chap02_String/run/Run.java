package com.kh.chap02_String.run;

import com.kh.chap02_String.controller.A_StringPool;
import com.kh.chap02_String.controller.B_StringBuilderAndBuffer;

public class Run {
	public static void main(String[] args) {
//		A_StringPool asp = new A_StringPool();
//		asp.method3();
//		
		B_StringBuilderAndBuffer bsb = new B_StringBuilderAndBuffer();
		bsb.method();
	}
}
