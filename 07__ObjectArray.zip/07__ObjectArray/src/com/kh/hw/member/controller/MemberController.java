package com.kh.hw.member.controller;

import java.util.Arrays;

import com.kh.hw.member.model.vo.Member;

public class MemberController {
	public static final int SIZE = 10;
	private Member[] m = new Member[SIZE]; // [null, null, null . . . ]

	public int existMemberNum() {
		int count = 0;
		for (Member member : m) {
			// 객체가 초기화된 경우 count++
			if (member != null)
				count++;
		}
		return count;
	}

	public boolean checkId(String inputId) {
		for (Member member : m) {
			if (member != null && member.getId().equals(inputId))
				return true;
		}
		return false;
	}

	public void insertMember(String id, String name, String password, String email, char gender, int age) {
		//객체 생성하는 경우엔 베이직 for 문을 써야 함
		
		for (int i = 0; i < m.length; i++) {
			if (m[i] == null) {
				m[i] = new Member(id, name, password, email, gender, age);
				break;
			}
		}
	}

	public String searchId(String id) {
		// 멤버 객체 배열에서 id와 일치하는 회원 정보 찾은 후 회원 정보 반환
		
		for (Member member : m) {
			if (member != null && member.getId().equals(id)) {
				return member.inform();
			}
		}
		return null;
	}

	public Member[] searchName(String name) {
		Member[] result = new Member[SIZE];
		int idx = 0;
		for (Member member : m) {
			if (member != null && member.getName().equals(name)) {
				result[idx++] = member;
			}
		}
		
		//찾고자 하는 회원이 한 명도 없는 경우
		if (idx == 0) {
			return null;
		}else {
//			Member[] copy = Arrays.copyOf(m, idx);
		return result;
		}
	}

	public Member[] searchEmail(String email) {
		Member[] result = new Member[SIZE];
		int idx = 0;
		for (Member member : m) {
			if (member != null && member.getEmail().equals(email)) {
				result[idx++] = member;
			}
		}
		return result;
	}

	public boolean updatePassword(String id, String password) {
		
		// Basic For Loop 
//		for(int i = 0; i<m.length; i++) {
//			Member mem = m[i];
//			if(mem != null && mem.getId().equals(id)) {
//				mem.setPassword(password);
//				return true;
//			}
//		}
//		return false;
		
		for (Member member : m) {
			if (member != null && member.getId().equals(id)) {
				member.setPassword(password);
				return true;
			}
		}
		return false;
	}

	public boolean updateName(String id, String name) {
		for (Member member : m) {
			if (member != null && member.getId().equals(id)) {
				member.setName(name);
				return true;
			}
		}
		return false;
	}

	public boolean updateEmail(String id, String email) {
		for (Member member : m) {
			if (member != null && member.getId().equals(id)) {
				member.setEmail(email);
				return true;
			}
		}
		return false;
	}

	public boolean delete(String id) {
		for (int i = 0; i < m.length; i++) {
			if (m[i] != null && m[i].getId().equals(id)) {
				m[i] = null;
				return true;
			}
		}
		return false;
	}

	public void delete() {
		//전체 회원을 삭제하는 메소드
		// m = new Member[SIZE];
		
		for (int i = 0; i < m.length; i++) {
			m[i] = null;
		}
	}

	public Member[] printAll() {
		return m;
	}
}