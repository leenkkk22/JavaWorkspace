package com.kh.hw.member.view;

import java.util.Scanner;


import com.kh.hw.member.controller.MemberController;
import com.kh.hw.member.model.vo.Member;


public class MemberMenu {
	private Scanner sc = new Scanner(System.in);
	private MemberController mc = new MemberController();

	public void mainMenu() {
	    while (true) {
	        System.out.println("최대 등록 가능한 회원 수는 " + MemberController.SIZE + "명입니다.");
	        System.out.println("현재 등록된 회원 수는 " + mc.existMemberNum() + "명입니다.");

	        if (mc.existMemberNum() == MemberController.SIZE) {
	            System.out.println("회원 수가 모두 꽉 찼기 때문에 일부 메뉴만 오픈됩니다.");
	            System.out.println("2. 회원 검색");
	            System.out.println("3. 회원 정보 수정");
	            System.out.println("4. 회원 삭제");
	            System.out.println("5. 모두 출력");
	            System.out.println("9. 끝내기");
	        } else {
	            System.out.println("1. 새 회원 등록");
	            System.out.println("2. 회원 검색");
	            System.out.println("3. 회원 정보 수정");
	            System.out.println("4. 회원 삭제");
	            System.out.println("5. 모두 출력");
	            System.out.println("9. 끝내기");
	        }

	        System.out.print("메뉴 번호 : ");

	        int menu = sc.nextInt();
	        sc.nextLine();

	        switch (menu) {
	        case 1:
	            if (mc.existMemberNum() < MemberController.SIZE)
	                insertMember();
	            else
	                System.out.println("회원 수가 모두 꽉 찼습니다.");
	            break;
	        case 2:
	            searchMember();
	            break;
	        case 3:
	            updateMember();
	            break;
	        case 4:
	            deleteMember();
	            break;
	        case 5:
	            printAll();
	            break;
	        case 9:
	            System.out.println("프로그램을 종료합니다.");
	            return;
	        default:
	            System.out.println("잘못 입력하셨습니다.");
	        }
	    }
	}


	public void insertMember() {
		String id;
		while (true) {
			System.out.print("아이디 : ");
			id = sc.nextLine();
			if (!mc.checkId(id))
				break;
			System.out.println("중복된 아이디입니다.");
		}

		System.out.print("이름 : ");
		String name = sc.nextLine();

		System.out.print("비밀번호 : ");
		String pw = sc.nextLine();

		System.out.print("이메일 : ");
		String email = sc.nextLine();

		char gender;
		while (true) {
			System.out.print("성별(M/F) : ");
			gender = sc.nextLine().toUpperCase().charAt(0);
			if (gender == 'M' || gender == 'F')
				break;
		}

		System.out.print("나이 : ");
		int age = sc.nextInt();
		sc.nextLine();

		mc.insertMember(id, name, pw, email, gender, age);
	}

	public void searchMember() {
		System.out.println("1. 아이디로 검색하기");
		System.out.println("2. 이름으로 검색하기");
		System.out.println("3. 이메일로 검색하기");
		System.out.println("9. 메인으로 돌아가기");
		int menu = sc.nextInt();
		sc.nextLine();

		if (menu == 1) {
			searchId();
		} else if (menu == 2) {
			searchName();
		} else if (menu == 3) {
			searchEmail();
		} else if (menu == 9){
			System.out.println("메인으로 돌아갑니다");
		} else {
			System.out.println("잘못 입력하셨습니다.");
		}
	}

	public void searchId() {
		System.out.print("아이디 : ");
		String id = sc.nextLine();
		String result = mc.searchId(id);
		if (result == null)
			System.out.println("검색 결과가 없습니다.");
		else
			System.out.println(result);
	}

	public void searchName() {
		System.out.print("이름 : ");
		String name = sc.nextLine();
		Member[] list = mc.searchName(name);
		boolean found = false;
		for (Member m : list) {
			if (m != null) {
				System.out.println(m.inform());
				found = true;
			}
		}
		if (!found)
			System.out.println("검색 결과가 없습니다.");
	}

	public void searchEmail() {
		System.out.print("이메일 : ");
		String email = sc.nextLine();
		Member[] list = mc.searchEmail(email);
		boolean found = false;
		for (Member m : list) {
			if (m != null) {
				System.out.println(m.inform());
				found = true;
			}
		}
		if (!found)
			System.out.println("검색 결과가 없습니다.");
	}

	public void updateMember() {
		System.out.println("1. 비밀번호 수정하기");
		System.out.println("2. 이름 수정하기");
		System.out.println("3. 이메일 수정하기");
		int menu = sc.nextInt();
		sc.nextLine();

		if (menu == 1)
			updatePassword();
		else if (menu == 2)
			updateName();
		else if (menu == 3)
			updateEmail();
		else System.out.println("잘못 입력하셨습니다.");
	}

	public void updatePassword() {
		System.out.print("아이디 : ");
		String id = sc.nextLine();
		System.out.print("비밀번호 : ");
		String pw = sc.nextLine();
		System.out.println(mc.updatePassword(id, pw) ? "수정이 성공적으로 되었습니다." : "존재하지 않는 아이디입니다");
	}

	public void updateName() {
		System.out.print("아이디 : ");
		String id = sc.nextLine();
		System.out.print("이름 : ");
		String name = sc.nextLine();
		System.out.println(mc.updateName(id, name) ? "수정이 성공적으로 되었습니다." : "존재하지 않는 아이디입니다");
	}

	public void updateEmail() {
		System.out.print("아이디 : ");
		String id = sc.nextLine();
		System.out.print("이메일 : ");
		String email = sc.nextLine();
		System.out.println(mc.updateEmail(id, email) ? "수정이 성공적으로 되었습니다." : "존재하지 않는 아이디입니다");
	}

	public void deleteMember() {
		System.out.println("1. 특정 회원 삭제");
		System.out.println("2. 전체 삭제");
		int menu = sc.nextInt();
		sc.nextLine();

		if (menu == 1)
			deleteOne();
		else if (menu == 2)
			deleteAll();
		else System.out.println("잘못 입력하셨습니다.");
	}

	public void deleteOne() {
		System.out.print("아이디 : ");
		String id = sc.nextLine();
		System.out.print("정말 삭제하시겠습니까?(y/n) : ");
		if (sc.nextLine().equalsIgnoreCase("y")) {
			System.out.println(mc.delete(id) ? "삭제가 성공적으로 되었습니다." : "존재하지 않는 아이디입니다");
		}
	}

	public void deleteAll() {
		System.out.print("정말 삭제하시겠습니까?(y/n) : ");
		if (sc.nextLine().equalsIgnoreCase("y")) {
			mc.delete();
			System.out.println("전체 삭제 완료");
		}
	}

	public void printAll() {
		Member[] list = mc.printAll();
		boolean empty = true;
		for (Member m : list) {
			if (m != null) {
				System.out.println(m.inform());
				empty = false;
			}
		}
		if (empty)
			System.out.println("저장된 회원이 없습니다.");
	}
/*
public class MemberMenu {
	private Scanner sc = new Scanner(System.in);
	private MemberController mc = new MemberController();

	public MemberMenu() {
		
		
			
			int memberNum = mc.existMemberNum();
			
			System.out.println("최대 등록 가능한 회원 수는 " + MemberController.SIZE + "명입니다.");
			System.out.println("현재 등록된 회원 수는 " + memberNum + "명입니다.");
			
			if (memberNum != MemberController.SIZE) {
				System.out.println("1. 새 회원 등록");
				
			} else {
				System.out.println("회원 수가 모두 꽉 찼기 때문에 일부 메뉴만 오픈됩니다.");
				
			}
			System.out.println("2. 회원 검색");
			System.out.println("3. 회원 정보 수정");
			System.out.println("4. 회원 삭제");
			System.out.println("5. 모두 출력");
			System.out.println("9. 끝내기");
			System.out.print("메뉴 번호 : ");
			
			int menu = sc.nextInt();
			
			switch(menu){
			case 1: 
				if(memberNum != MemberController.SIZE) {
					insertMember();
				
				}
				break;
			case 2:
				searchMember();
				break;
				
			case 3:
				updateMember();
				break;
			case 4:
				deleteMember();
			case 5:
				printAll();
				
			case 9:
				default :
					System.out.println("잘못 입력");
					
							
			}
		
	}

	public void mainMenu() {

	}

	public void insertMember() {
		System.out.println("아이디 : ");
		String id = sc.next();
		
		boolean isDup = mc.checkId(id);
		if(isDup) { //중복인 경우
			System.out.println("중복된 아이디 입력, 다시 입력하세요.");
			insertMember();
			return;
			
		}
		System.out.println("이름 : ");
		String name = sc.next();
		System.out.println("비밀번호 : ");
		String password = sc.next();
		System.out.println("이메일 : ");
		String email = sc.next();
		
		char gender = '\u0000';
		while(true) {
		System.out.println("성별 : ");
		gender = sc.next().toUpperCase().charAt(0);
		
		if (gender == 'm' || gender == 'F') {
			break;
		}
		}
	}
		


	
	public boolean checkId(String inputId) {
		//아이디 중복확인
		boolean isDup = false;
		for(Member mem : m) {
			//객체 배열에 저장된 멤버 객체의 id값 / 사용자 값 비교
			if(mem != null && inputId.equals(mem.getId())) {
				isDup = true;
				break;
			}
		}
		return isDup;
	}

	public void searchMenu() {
		System.out.println("1. 아이디");
		System.out.println("2. 이름");
		System.out.println("9. 메인");
		System.out.print("메뉴 번호");
		int menu = sc.nextInt();
		switch (menu) {
		case 1:
			
		case 2:
		case 9:
		}

	}

	public void searchId() {
		System.out.println("검색 아이디: ");
		String searchid = sc.next();
		
		String result = mc.searchId(searchid);
		
		if (result != null) {
			System.out.println("찾으신 회원 조회 결과입니다.");
			System.out.println(result);
		}else {
			System.out.println("검색 결과가 없습니다.");
			
		}

	}

	public void searchName() {

	}
	public void searchMember() {
		
	}

	public void updateMember() {

	}

	public void updatePassword() {
		System.out.println("수정할 회원 id: ");
		String id = sc.next();
		System.out.println("수정할 회원 비밀번호");
		String password = sc.next();
		
		boolean result = mc.updatePassword(id, password);
		if(result) {
			System.out.println("비번 변경 성공");
		} else {
			System.out.println("존재하지 않는 아이디");
		}

	}

	public void deleteMember() {
		System.out.println("번호 선택: ");
		int menu = sc.nextInt();
		switch (menu) {
		case 1:
			deleteOne();
			break;
		case 2:
			deleteAll();
			break;
		case 9:
			return;
		}

	}

	public void deleteOne() {
		System.out.print("삭제할 회원 아이디: ");
		String id = sc.next();
		
		System.out.println("진짜 삭제할 건가요? (Y/N)");
		char ch = sc.next().toUpperCase().charAt(0);
		
		if(ch != 'Y') {
			System.out.println("메인으로 돌아갑니다.");
			return;
		}
		boolean result = mc.delete(id);
		if(result) {
			System.out.println("삭제 성공");
			
		}else {
			System.out.println("존재하지 않는 아이디");
		}
		

	}

	public void deleteAll() {
		System.out.println("진짜 삭제할 건가요? (Y/N)");
		char ch = sc.next().toUpperCase().charAt(0);
		
		if(ch != 'Y') {
			System.out.println("메인으로 돌아갑니다.");
			return;
		}
		mc.delete(id);
		

	}

	public void printAll() {
		Member[] m = mc.printAll();
		int memberNum = mc.existMemberNum();
		if(memberNum == 0) {
			System.out.println("저장할 회원이 없습니다.");
			return;
		}
		
		for(Member mem :m) {
			if (mem != null)
			System.out.println(mem);
		}

	}
*/
	
	 
}