package com.kh.hw.person.view;

import java.util.Scanner;

import com.kh.hw.person.controller.PersonController;
import com.kh.hw.person.model.vo.Student;

public class PersonMenu {
	
	Scanner sc = new Scanner(System.in);
	PersonController pc = new PersonController();
	public void mainMenu() {
		
		while(true ) {
			int [] count = pc.PersonCount(); //PersonCount 값을 count 배열에 저장
			System.out.println("학생은 최대 3명까지 저장할 수 있습니다.");
			System.out.println("현재 저장된 학생은 "+ count[0]+"명입니다."); //std 카운트
			System.out.println("최대 10명까지 저장할 수 있습니다.");
			System.out.println("현재 저장된 사원은 "+ count[1]+ "명입니다."); //emp 카운트
			
			System.out.print("1. 학생 메뉴: ");
			System.out.print("2. 사원 메뉴: ");
			System.out.print("9. 끝내기 ");
			System.out.print("메뉴 번호 : ");
			
			int menu = sc.nextInt();
			
			switch(menu) {
			case 1:
				studentMenu();
				break;
			case 2:
				employeeMenu();
				break;
				
			case 9:
				System.out.println("종료합니다");
				return;
			default :
				System.out.println("잘못 입력하셨습니다");
				return;
			}
			
		}
		
	}
	
	public void studentMenu() {
		
		while(true) {
			
			System.out.print("1.학생 추가");
			System.out.print("2.학생 보기");
			System.out.print("9. 메인으로");
			int count = pc.PersonCount()[0]; // 학생 수가 저장된 배열 불러오기
			if (count == 3) {
				System.out.println("학생 공간 꽉 차서 활성화되지 않는 메뉴");
			}
			
			System.out.println(" 메뉴 번호: ");
			int menu = sc.nextInt();
			
			switch(menu) {
			case 1:
				if(count ==3) { // 학생 수 꽉 차면 1번 메뉴 비활성화
					System.out.println("잘못된 입력입니다.");
					continue;
				}
				insertStudent();
				break;
			case 2:
				printStudent();
				break;
			case 9:
				System.out.println("메인으로 돌아갑니다");
				return;
			default :
				System.out.println("잘못 입력하셨습니다. 다시 입력해주세요");
			}
			
			// 만일 학생 객체 배열에 담긴 데이터의 수가 3개 일 때
			// “학생을 담을 수 있는 공간이 꽉 찼기 때문에 학생 추가 메뉴는 더 이상
			// 활성화 되지 않습니다.”를 출력 후 메뉴 번호를 담음
			// 실제로 1번을 누르면 “잘못 입력하셨습니다. 다시 입력해주세요.”를 출력
			
			// 학생 객체 배열에 담긴 데이터의 수가 3개가 아닐 때는
			// 위에 출력한 메뉴 모두 받을 수 있게 함			
			// 잘못 입력했을 경우, “잘못 입력하셨습니다. 다시 입력해주세요.” 출력 후 반복
			
		}
	}
	
	public void employeeMenu() {
		while(true) {
			System.out.print("1.사원 추가");
			System.out.print("2.사원 보기");
			System.out.print("9. 메인으로");
			System.out.print(" 메뉴 번호: ");
			int menu = sc.nextInt();
			
			switch(menu) {
			case 1:
				insertEmployee();
				break;
			case 2:
				printEmployee();
				break;
			case 9:
				System.out.println("메인으로 돌아갑니다");
				return;
				default :
					System.out.println("잘못 입력하셨습니다. 다시 입력해주세요");
					return;
			}
		}
	}
	
	public void insertStudent() {
		
		while (true) {
			
			System.out.print("학생 이름: ");
			String name = sc.next();
			System.out.print("학생 나이: ");
			int age = sc.nextInt();
			System.out.print("학생 키: ");
			double height = sc.nextDouble();
			System.out.print("학생 몸무게: ");
			double weight = sc.nextDouble();
			System.out.print("학생 학년: ");
			int grade = sc.nextInt();
			System.out.print("학생 전공: ");
			String major = sc.next();
			
			pc.insertStudent(name, age, height, weight, grade, major);
			int count = pc.PersonCount()[0]; 
			if(count != 3) { // 저장된 학생 수가 3명보다 적다면
				System.out.print("그만하려면 N, 이어 하려면 아무 키 입력");
				char ch = sc.next().toUpperCase().charAt(0);
				
				if(ch == 'N' || ch =='n') {
					break;
					
				}else {
					System.out.println("꽉 차서 학생 메뉴로 복귀");
					break;
				}
			}
		}
	}
	
	public void printStudent() {
		// pc의 printStudent() 메소드의 반환 값을 이용하여 학생 객체 배열에 저장된
		// 모든 데이터 출력
		Student [] s = pc.printStudent();
		for(Student std : s) {
			if(std != null) System.out.println(std);
		}
	}
	
	public void insertEmployee() {
		System.out.print("사원 이름: ");
		String name = sc.next();
		System.out.print("사원 나이: ");
		int age = sc.nextInt();
		System.out.print("사원 키: ");
		double height = sc.nextDouble();
		System.out.print("사원 몸무게: ");
		double weight = sc.nextDouble();
		System.out.print("사원 급여: ");
		int salary = sc.nextInt();
		System.out.print("사원 부서: ");
		String dept = sc.next();
		
		
	}
	
	public void printEmployee() {
		
		String result = null;
		System.out.println(result);
		
	}

	/*
	 * package com.kh.hw.person.view;
import java.util.Scanner;
import com.kh.hw.person.controller.PersonController;
import com.kh.hw.person.model.vo.Employee;
import com.kh.hw.person.model.vo.Student;
public class PersonMenu {
	private Scanner sc = new Scanner(System.in);
	private PersonController pc = new PersonController();
	public void mainMenu() {
		while(true) {
			int [] count = pc.personCount();
			System.out.println("학생은 최대 3명까지 저장할 수 있습니다. \r\n"
					+ "현재 저장된 학생은 "+count[0]+"명입니다. \r\n"
					+ "사원은 최대 10명까지 저장할 수 있습니다. \r\n"
					+ "현재 저장된 사원은 "+count[1]+"명입니다. ");
			System.out.println("1. 학생 메뉴");
			System.out.println("2. 사원 메뉴");
			System.out.println("9. 끝내기 ");
			System.out.print("메뉴 번호 : ");
			int menu = sc.nextInt();
			
			switch(menu) {
			case 1:
				studentMenu();
				break;
			case 2:
				employeeMenu();
				break;
			case 9:
				System.out.println("종료");
				return;
			default:
				System.out.println("잘못 입력하셨습니다.");
			}
		}
	}
	public void studentMenu() {
		
		while(true) {
			System.out.println("1. 학생 추가");
			System.out.println("2. 학생 보기");
			System.out.println("9. 메인으로");
			int count = pc.personCount()[0];
			if(count == 3) {
				System.out.println("학생을 담을 수 있는 공간이 꽉 찼기 때문에 학생 추가 메뉴는 더 이상 \r\n"
						+ "활성화 되지 않습니다.");
			}
			System.out.print("메뉴번호 : ");
			int menu = sc.nextInt();
			
			switch(menu) {
			case 1:
				if(count == 3) {
					System.out.println("잘못 입력하셨습니다. 다시 입력해주세요.");
					continue;
				}
				insertStudent();
				break;
			case 2:
				printStudent();
				break;
			case 9:
				return;
			}			
		}
	}
	public void employeeMenu() {
	}
	public void insertStudent() {
		while(true) {
			System.out.print("학생 이름 : ");
			String name = sc.next();
			
			System.out.print("학생 나이 : ");
			int age = sc.nextInt();
			
			System.out.print("학생 키 : ");
			double height = sc.nextDouble();
			
			System.out.print("학생 몸무게 : ");
			double weight = sc.nextDouble();
			
			System.out.print("학생 학년 : ");
			int grade = sc.nextInt();
			
			System.out.print("학생 전공 : ");
			String major = sc.next();
			
			pc.insertStudent(name, age,height, weight, grade, major);
			
			int count = pc.personCount()[0];
			if(count != 3) {
				System.out.print("그만하시려면 N(또는 n), 이어하시려면 아무 키나 누르세요 : ");
				char ch = sc.next().toUpperCase().charAt(0);
				
				if(ch == 'N') {
					break;
				}
			}else {
				System.out.println("학생을 담을 수 있는 공간이 꽉 찼기 때문에 학생 추가를 종료하고  \r\n"
						+ "학생 메뉴로 돌아갑니다.");
				break;
			}
		}
	}
	public void printStudent() {
		// pc의 printStudent() 메소드의 반환 값을 이용하여 학생 객체 배열에 저장된
		// 모든 데이터 출력
		Student[] s = pc.printStudent();
		for(Student std : s) {
			if(std != null) System.out.println(std);
		}
	}
	public void insertEmployee() {
	}
	public void printEmployee() {
		Employee[] arr = pc.printEmployee();
		for(Employee std : arr) {
			if(std != null) System.out.println(std);
		}
	}
}
	 * */
}
