package com.kh.practice.point.run;

import com.kh.practice.point.view.PointMenu;

public class Run {
	public static void main(String[] args) {
		PointMenu pm = new PointMenu();
		pm.mainMenu();
	}

}
