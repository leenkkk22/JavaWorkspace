package com.kh.practice.point.controller;

import com.kh.practice.point.model.vo.Point;
import com.kh.practice.point.model.vo.Rectangle;

public class RectangleController extends Point{
	
	private Rectangle r = new Rectangle();
	
	
	public String calcArea(int x, int y, int height, int width) {
		return "면적: " + x + ", " + y +" " + height + " " + width + " / " +(height*width);
		
		
		
	}
	
	public String calcPerimeter(int x, int y, int height, int width) {
		return height + " " + width + " " + height * width;
	}
	
	

}
