package com.kh.practice.chap02_abstractNInterface.model.vo;

public interface NotePen {
	
	boolean PEN_BUTTON = true;
	
	boolean bluetoothPen();

}
