package com.kh.practice.chap02_abstractNInterface.model.vo;

public interface TouchDisplay {
	
	String touch();

}
