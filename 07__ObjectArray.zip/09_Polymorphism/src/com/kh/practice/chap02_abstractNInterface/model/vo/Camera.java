package com.kh.practice.chap02_abstractNInterface.model.vo;

public interface Camera {
	
	String picture();

}
