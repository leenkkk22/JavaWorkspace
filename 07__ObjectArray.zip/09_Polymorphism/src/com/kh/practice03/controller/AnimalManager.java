package com.kh.practice03.controller;



import com.kh.chap01_poly.part01.model.vo.Child1;
import com.kh.chap01_poly.part01.model.vo.Child2;
import com.kh.practice03.model.vo.*;


public class AnimalManager {
	public static void main(String[] args) {
		
		
		// Animal 타입의 객체배열 크기 5로 생성
		// 각 인덱스에 무작위로 Dog객체 또는 Cat객체로 생성
		// (이때, 매개변수 생성자를 이용하여 생성)
		// 반복문을 통해서 해당 배열의 0번 인덱스부터 마지막 인덱스까지의
		// 객체의 speak() 메소드 호출
		
		Animal [] arr = new Animal[5];
		
		arr[0] = new Dog("설탕", "진돗개", 16);
		arr[1] = new Cat("쿠키", "샴", "나무","갈색");
		arr[2] = new Dog("초코", "푸들", 8);
		arr[3] = new Dog("베리", "IG", 14);
		arr[4] = new Dog("코코", "시츄", 11);
		
		//for each
//		for(Animal ani : arr) {
//			ani.speak();
//		}
		for(int i = 0; i< arr.length; i++) {
		
			if(arr[i] instanceof Dog ) {
				
				((Dog)arr[i]).speak();
			} else if(arr[i] instanceof Cat) {
				
				((Cat)arr[i]).speak();
			}
		
		}
		
			
	}
	}
	


