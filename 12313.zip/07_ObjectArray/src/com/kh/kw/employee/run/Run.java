package com.kh.kw.employee.run;

import com.kh.kw.employee.view.EmployeeMenu;

public class Run {

	public static void main(String[] args) {
		EmployeeMenu em = new EmployeeMenu();
		
		

	}

}
