package com.kh.example.practice4.run;

import com.kh.example.practice4.model.vo.Student;

public class run {
	public static void main(String[] args) {
		Student st = new Student();
		st.information();
	}

}
