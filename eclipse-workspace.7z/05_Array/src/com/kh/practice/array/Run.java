package com.kh.practice.array;

public class Run {

	public static void main(String[] args) {
		ArrayPractice ap = new ArrayPractice();
		ap.practice10();
		
	

	}

}
