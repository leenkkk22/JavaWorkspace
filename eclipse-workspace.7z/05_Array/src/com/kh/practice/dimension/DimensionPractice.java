package com.kh.practice.dimension;

import java.util.Arrays;
import java.util.Scanner;

public class DimensionPractice {
	Scanner sc = new Scanner(System.in);

	public void practice1() {
		String[][] str = { { "(0,0)" }, { "0,1)", ("(0,2)") }, { "(1,0)" }, { "(1,1)" }, { "(1,2)" }, { "(2,0)" },
				{ "(2,1)" }, { "(2,2)" } };
		for (int i = 0; i < str.length; i++) {
			for (int j = 0; j < str[i].length; j++) {
				System.out.print(str[i][j] + " ");
			}
		}

	}

	public void practice2() {
		int[][] arr = new int[4][4];
		int value = 1;
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[i].length; j++) {
				arr[i][j] = value++;

			}
		}
		for (int i = 0; i < arr.length; i++) {

			for (int j = 0; j < arr[i].length; j++) {

				System.out.print(arr[i][j] + " ");
			}
			System.out.println();
		}

	}

	public void practice3() {
		int[][] arr = new int[4][4];
		int value = 16;

		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[i].length; j++) {
				arr[i][j] = value--;

				System.out.print(arr[i][j] + " ");
			}
			System.out.println();

		}
	}
	
	
	public void practice4() {
		int [][] arr = new int[4][4];
		
		for (int i = 0; i<arr.length -1 ; i++) {
			for(int j = 0; j<arr[i].length -1  ; j++) {
				int rd = (int)(Math.random() * 10 + 1);
				arr[i][j] = rd;
				arr[3-i][3-j] +=arr[i][j];
				
			};
			}
		
		for(int i = 0; i<arr.length; i++){
			System.out.println(Arrays.toString(arr[i]));
		}
		// ㅇㅇ
		}

		
		
		
	}

