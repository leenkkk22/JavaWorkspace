package com.kh.exception.controller;

import java.util.InputMismatchException;
import java.util.Scanner;

public class A_UncheckedException {
	Scanner sc = new Scanner(System.in);
	public void method2() {
		System.out.println("정수 입력(0제외) : ");
		try {
			int num = sc.nextInt();
			System.out.println("나눗셈 연산 결과 : " + (10/num));
			
		}catch(ArithmeticException e ) {
			System.out.println("0으로 나눌 수 없습니다.");
			
		}catch(InputMismatchException i) {
			System.out.println("정수만 입력하세요.");
		} // 다중예외처리문법 : 예외가 여러 개인 경우 사용
		
		System.out.println("프로그램 종료");
	}
	
	public void method3() {
		// ArrayIndexOutOfBoundException 배열의 인덱스 값을 벗어나는 경우
		// NegativeArraySizeException 배열의 크기 지정에서 음수를 지정하는 경우
		
		System.out.println("배열의 크기: ");
		int size = sc.nextInt();
		
		// 예외처리 1번 방식. 다중 catch 블럭 /-/ 길어지면 보기 힘듦
//		try {
//			int [] arr = new int[size]; //NegativeArray... 에러가 발생할 수 있는 코드
//			System.out.println("100번째 인덱스의 값: " + arr[100]); //ArrayIndexOut...에러 발생 가능			
//		}catch(NegativeArraySizeException e ) {
//			System.out.println("배열의 크기는 음수일 수 없습니다.");
//		}catch(ArrayIndexOutOfBoundsException e) {
//			System.out.println("부적절한 인덱스입니다.");			
//		}
		
		// 처리방법 2. 다형성을 이용한 catch 블럭 만들기
		try {
			int [] arr = new int[size]; //NegativeArray... 에러가 발생할 수 있는 코드
			System.out.println("100번째 인덱스의 값: " + arr[100]); //ArrayIndexOut...에러 발생 가능
			
			// 다중 catch블럭 작성시 범위가 작은 자식 클래스를 먼저 기술해야 한다.
		}catch(ArrayIndexOutOfBoundsException e) { 
			System.out.println("잘못된 인덱스 접근입니다.");
		}catch(RuntimeException e) { //다형성 적용
			System.out.println("예외가 발생했습니다."); // 정확히 어떤 에러가 발생했는지 파악할 수 없다.
			e.printStackTrace(); // 에러 코드 출력
			}
		/*
		 * RuntiemException 관련된 예외는 
		 *   - 조건문으로 해결이 가능하기 때문에 예외 자체가 애초에 발생 안 되게끔 개발자가 소스 코드로 핸들링하는게 권장된다.
		 *   - 예외처리 구문으로도 해결이 가능하긴 하다.
		 *   
		 * 예측이 가능한 상황  => 조건문으로 해결
		 * 예측이 불가능한 상황 => 예외처리 구문으로 해결
		 *  
		 * */		
		
		
		
	}

}
