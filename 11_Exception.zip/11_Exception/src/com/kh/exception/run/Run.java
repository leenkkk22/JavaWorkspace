package com.kh.exception.run;

import com.kh.exception.controller.*;
public class Run {
	public static void main(String[] args) throws C_CustomException {
		A_UncheckedException aue = new A_UncheckedException();
//		aue.method3();
		
		B_CheckedEcxception bce = new B_CheckedEcxception();
//		bce.method1();
		
		//에러 강제 발생
		// throw new 에러클래스 생성자(에러메시지):
		throw new C_CustomException("에러발생");
	}
}
