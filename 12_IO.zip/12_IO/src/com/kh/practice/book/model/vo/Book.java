package com.kh.practice.book.model.vo;

import java.util.Calendar;

public class Book {
	private String tilte;
	private String author;
	private int price;
	private Calendar date;
	private double discount;
	
	
	public Book() {
		
	}


	public Book(String tilte, String author, int price, Calendar date, double discount) {
		super();
		this.tilte = tilte;
		this.author = author;
		this.price = price;
		this.date = date;
		this.discount = discount;
	}


	public String getTilte() {
		return tilte;
	}


	public void setTilte(String tilte) {
		this.tilte = tilte;
	}


	public String getAuthor() {
		return author;
	}


	public void setAuthor(String author) {
		this.author = author;
	}


	public int getPrice() {
		return price;
	}


	public void setPrice(int price) {
		this.price = price;
	}


	public Calendar getDate() {
		return date;
	}


	public void setDate(Calendar date) {
		this.date = date;
	}


	public double getDiscount() {
		return discount;
	}


	public void setDiscount(double discount) {
		this.discount = discount;
	}


	@Override
	public String toString() {
		return "Book [tilte=" + tilte + ", author=" + author + ", price=" + price + ", date=" + date + ", discount="
				+ discount + "]";
	}
	
	

}
