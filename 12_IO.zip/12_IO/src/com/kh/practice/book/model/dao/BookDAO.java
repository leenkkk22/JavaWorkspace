package com.kh.practice.book.model.dao;

import com.kh.practice.book.model.vo.Book;

public class BookDAO {
	private Book [] bArr = new Book[10];
	
	public void fileSave(Book [] bArr) {
		
	}
	
	public Book[] fileRead() {
		
	}
	

}
