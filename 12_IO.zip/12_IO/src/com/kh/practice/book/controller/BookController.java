package com.kh.practice.book.controller;

import com.kh.practice.book.model.dao.BookDAO;
import com.kh.practice.book.model.vo.Book;

public class BookController {
	private BookDAO bd = new  BookDAO();

	public void makeFile() {
		
	}
	
	public void fileSave(Book[] bArr) {
		
	}
	
	public Book[] fileRead() {
		
	}
	
}
