//package com.kh.practice.file.model.dao;
//
//import java.io.File;
//import java.io.FileNotFoundException;
//import java.io.FileReader;
//import java.io.FileWriter;
//import java.io.IOException;
//
//// OOP 프로그래밍 상 메뉴에서 DAO로 곧바로 접근하진 않는다. 
//// Menu -> Controller -> DAO 식으로 호출해서 작성
//public class FileDAO {
//	FileWriter fw = null;
//	public boolean checkName(String file) {
//		File f = new File(file);
//		return f.exists();
//		
////		fileEdit(file);
////		
////		boolean check = true;
////		return check; // xxx
//	}
//	
//	public void fileSave(String file, String s) {
//		
//		try {
//			// 파일 생성은 fw가 알아서(이미 존재하면 안 함)
//			fw = new FileWriter(file);
//			fw.write(s);
//			
//		} catch (IOException e) {
//			e.printStackTrace();
//		}finally {
//			try {
//				fw.close();
//			} catch (IOException e) {
//				e.printStackTrace();
//			}
//		}
//		
//		//내가 작성한거
////		File file1 = new File(file);
////		try {
////			fw = new FileWriter(s);
////		} catch (IOException e) {
////			e.printStackTrace();
////		}
//		
//	}
//	
//	public StringBuilder fileOpen (String file){
//		FileReader fr = null;
//		StringBuilder sb = new StringBuilder();
//		
//		try {
//			fr = new FileReader(file);
//			
//			int value = 0;
//			while( (value = fr.read()) != -1) {
//				sb.append((char)value);
//			}
//		} catch (FileNotFoundException e) {
//			e.printStackTrace();
//		} catch (IOException e) {
//			e.printStackTrace();
//		} finally {
//			try {
//				fr.close();
//			} catch (IOException e) {
//				e.printStackTrace();
//			}
//		}
//		
//	}
//	
//	public void fileEdit(String file, String s) {
//		FileWriter fw = null;
//		
//		try {
//			fw = new FileWriter(file, true);
//		} catch (IOException e) {
//			e.printStackTrace();
//		}finally {
//			try {
//				fw.close();
//			} catch (IOException e) {
//				e.printStackTrace();
//			}
//		}
//		
//	}
//
//}
