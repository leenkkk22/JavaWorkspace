package com.kh.practice.score.controller;

import java.io.DataInputStream;
import java.io.FileNotFoundException;

import com.kh.practice.score.model.dao.ScoreDAO;

public class ScoreController {
	ScoreDAO sda = new ScoreDAO();
	
	public void saveScore(String name, int kor, int eng, int mat, int sum, double avg) {
	
		sda.saveScore(name, kor, eng, mat, sum, avg);
	}
	
	public DataInputStream readScore() throws FileNotFoundException {
		return sda.readScore();
	}

}
