package com.kh.practice.list.music.view;

import java.util.List;
import java.util.Scanner;

import com.kh.practice.list.music.controller.MusicController;
import com.kh.practice.list.music.model.vo.Music;

public class MusicView {
	
	private Scanner sc = new Scanner(System.in);
	private MusicController mc = new MusicController();
	
	public void mainMenu() {
		
		while(true) {
			System.out.println("******** 메인 메뉴 *********");
			System.out.println("1. 마지막 위치에 곡 추가");
			System.out.println("2. 첫 위치에 곡 추가");
			System.out.println("3. 전체 곡 목록 출력");
			System.out.println("4. 특정 곡 검색");
			System.out.println("5. 특정 곡 삭제");
			System.out.println("6. 특정 곡 정보 수정");
			System.out.println("7. 곡명 오름차순 정렬");
			System.out.println("8. 가수명 내림차순 정렬");
			System.out.println("9. 종료");
			System.out.print("메뉴 번호 선택: ");
			int menu = sc.nextInt();
			switch(menu) {
			case 1: 
				addList();
				break;
			case 2:
				addAtZero();
				break;
			case 3:
				printAll();
					break;
				
			case 4:
				searchMusic();
				break;
			case 5:
				removeMusic();
				break;
			case 6: 
				setMusic();
				break;
			case 7:
				ascTitle();
				break;
			case 8:
				descSinger();
				break;
			case 9:
				System.out.println("종료");
				return;
				default:
					System.out.println("잘못 입력");
			}
			
		}
		
	}
	
	public void addList() {
		
		System.out.println("****** 마지막 위치에 곡 추가 ******");
		// 곡 명과 가수 명을 사용자에게 입력 받는다.
		// MusicController에 addList()를 이용해서 입력한 정보를 넘기고
		// 추가 성공 시 “추가 성공”, 추가 실패 시 “추가 실패” 콘솔창에 출력
		
		System.out.print("곡 명 : ");
		String title = sc.next();
		sc.nextLine();
		System.out.print("가수 명 :");
		String artist = sc.next();
		Music m = new Music(title, artist);
		int result = mc.addList(m);
		
		if(result == -1 ) {
			System.out.println("추가 실패");
		}else {
			System.out.println("추가 성공");
		}
		
		
	}
	public void addAtZero() {
		System.out.println("****** 첫 위치에 곡 추가 ******");
		

		System.out.print("곡 명 : ");
		String title = sc.next();
		sc.nextLine();
		System.out.print("가수 명 :");
		String artist = sc.next();
		Music m = new Music(title, artist);
		int result = mc.addAtZero(m);
		
		if(result == -1 ) {
			System.out.println("추가 실패");
		}else {
			System.out.println("추가 성공");
		}
		
	}
	
	public void printAll () {
		List list = mc.printAll();
		System.out.println(list);
	}
	
	public void searchMusic() {
		// 사용자에게 곡 이름을 받고 MusicController에 있는 searchMusic으로 값을 넘긴다.
		// searchMusic()의 반환 값에 따라 반환 값이 없으면 “검색한 곡이 없습니다.”
		// 반환 값이 있으면 “검색한 곡은 000(곡 명, 가수 명) 입니다.” 콘솔 창에 출력
		
		System.out.println("****** 특정 곡 검색 ******");
		System.out.print("검색할 곡 명: ");
		String title = sc.next();
		
		
		
		Music m = mc.searchMusic(title);
		
		if(m==null) {
			System.out.println("없습니다");
		}else {
			System.out.println(m.getTitle() + m.getSinger());
		}
		System.out.println(m);
	}
	
	public void removeMusic() {
		System.out.println("****** 특정 곡 삭제 ******");
		// 사용자에게 삭제할 곡의 이름을 직접 받고 MusicController에 removeMusic으로
		// 값을 넘긴다. removeMusic()의 반환 값에 따라 반환 값이 없으면 “ 삭제할 곡이 없습니다.”
		// 반환 값이 있으면 “000(곡 명, 가수 명)을 삭제 했습니다” 콘솔 창에 출력
		System.out.print("삭제할 곡 명: ");
		String title  = sc.next();
		sc.nextLine();
		
		Music m = mc.removeMusic(title);
		
		System.out.println(m + "을 삭제 했습니다.");
		System.out.println("삭제할 곡이 없습니다.");
	}
	
	public void setMusic() {
		
	}
	
	public void ascTitle() {
		int result = mc.ascTitle();
		
		if (result == 1) {
			System.out.println("정렬 성공");
			
		} else {
			System.out.println("정렬 실패");
			
		}
	}
	public void descSinger() {
		System.out.println("가수명 내림차순 정렬");
		int result = mc.descSinger();
		
		if(result == 1) {
			System.out.println("정렬 성공");
		} else {
			System.out.println("정렬 실패");
		}
		
	}

}
