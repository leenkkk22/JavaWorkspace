package com.kh.practice.list.music.controller;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import com.kh.practice.list.music.model.vo.Music;

public class MusicController {
	
	int count = 0;
	private List list = new ArrayList();
	
	
	public int addList(Music music) {
	
	list.add(music);
	
	count++;
	if (list.indexOf(count) == -1 ) {
		return 0;
	} else {
		return 1;
	}
	
	
	}
	
	
	public int addAtZero(Music music) {
		list.add(0, music);
		
		
		if (list.indexOf(0) == -1 ) {
			return 0;
		} else {
			return 1;
		}
	}
	
	public List printAll() {
		return list;
	}
	
	public Music searchMusic(String title) {
		// 곡 명으로 객체 검색, 객체가 있으면 객체 정보 리턴, 없으면 null 리턴
		
//		System.out.println(list.contains(title));
//		System.out.println(title);
//		System.out.println(list);
//		System.out.println(list.get(0));
		
		for(Object o :list)
			Music music =(Music) o;
		if(music.getTitle().equals(title)) {
			m = music;
			break;
			
			
			return m;	
		} else return null;
		
	}
	
	public Music removeMusic(String title) {
		// 곡 명으로 객체 검색, 객체가 있으면 객체 정보 삭제, 없으면 null 리턴

	}
	
	public Music setMusic(String title, Music music) {
		
		
		
	}
	
	public int ascTitle() {
		Collections.sort(list, new AscTitle());
		
		return 1;
	}
	
	public int descSinger() {
		Collections.sort(list);
		return 1;
	}



	

}
