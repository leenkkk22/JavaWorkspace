package com.kh.practice.thread;

import com.kh.practice.thread.EmptyException;
public class Data {

	private int value;

	private boolean isEmpty = true;

	public Data() {
		
	}
	public int getValue() throws EmptyException{
		synchronized(this) {
			if(isEmpty) {
				try {
					wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			
			value = this.value;
			int num = value;
			if(value ==0) {
				throw new EmptyException("현재 입력된 값이 없습니다. 기다리십시오...");
			}
			isEmpty = true;
			System.out.println("get value: "+ value);
			System.out.println("값을 꺼냈습니다. value가 비었습니다.");
			notify();
			
			return value = 0;
			
		}
	}

	
	
	public void setValue(int num) {
		synchronized(this) {
			if(isEmpty == false) {
				try {
					wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			
			value = num;
			isEmpty = false;
			System.out.println("값이 입력되었습니다.");
			System.out.println("put value: " + value);
			
			notify();
		}
	}
}
