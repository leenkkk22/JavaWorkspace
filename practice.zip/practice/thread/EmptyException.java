package com.kh.practice.thread;

@SuppressWarnings("serial")
public class EmptyException extends Exception{
	public EmptyException() {
		
	}
	
	public EmptyException(String message) {
		super(msg);
		
	}

}
