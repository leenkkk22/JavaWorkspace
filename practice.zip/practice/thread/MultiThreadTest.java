package com.kh.practice.thread;

public class MultiThreadTest {
	public static void main(String[] args) {
		
		Data data = new Data(); // 공유 데이터
		
		Thread putThread = new Thread(new Provider(data));
		Thread getThread = new Thread(new Customer(data));
		
		// data를 공유하는 Provider와 Customer 객체 생성 : Thread 객체 생성함
		
		// Thread 구동
		putThread.start();
		getThread.start();
	}

}
