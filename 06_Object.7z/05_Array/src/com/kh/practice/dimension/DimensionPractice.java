package com.kh.practice.dimension;

import java.util.Arrays;
import java.util.Scanner;

public class DimensionPractice {
	Scanner sc = new Scanner(System.in);

	public void practice1() {
		String[][] str = new String [3][3];
		for (int i = 0; i < str.length; i++) {
			for (int j = 0; j < str[i].length; j++) {
				str[i][j] = ("("+i+","+j+")");
				System.out.print(str[i][j] +" ");
			}System.out.println();
		}
		
		//선생님이 만드신 거
		/*
		String[][] arr = new String[3][3];
		
		for (int i = 0; i<arr.length; i++) {
			for(int j = 0; j<arr[i].length; j++) {
				arr[i][j] = "(" + i +","  + j+ ")";
				System.out.print(arr[i][j]);
			}
		}System.out.println();
		*/

	}

	public void practice2() {
		int[][] arr = new int[4][4];
		int value = 1;
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[i].length; j++) {
				arr[i][j] = value++;

				System.out.print(arr[i][j] + " ");
			}
			System.out.println();
		}
	

	}

	public void practice3() {
		int[][] arr = new int[4][4];
		int value = 16;

		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[i].length; j++) {
				arr[i][j] = value--;

				System.out.print(arr[i][j] + " ");
			}
			System.out.println();

		}
	}
	
	
	public void practice4() {
		/*
		int [][] arr = new int[4][4];
		
		for (int i = 0; i<arr.length -1 ; i++) {
			for(int j = 0; j<arr[i].length -1  ; j++) {
				int rd = (int)(Math.random() * 10 + 1);
				arr[i][j] = rd;
				arr[i][3] += rd;
				arr[3][j] += rd;	
				
			} 
			}arr[3][3] = arr[0][3] + arr[1][3] + arr[2][3] + arr[3][0] + arr[3][1] + arr[3][2];
		
		for(int i = 0; i<arr.length; i++){
			System.out.println(Arrays.toString(arr[i]));
		}
		*/
		//선생님이 만드신 거
		int[][] arr2 = new int [4][4];
		
		for(int i =0; i<arr2.length-1; i++) {
			for(int j=0; j<arr2[i].length-1; j++) {
				arr2[i][j] = (int)(Math.random() * 10 +1);
				arr2[i][3] += arr2[i][j];
				arr2[3][j] += arr2[i][j];
				arr2[3][3] += arr2[i][j] *2;
			}
		}
		for(int i = 0; i<arr2.length; i++) {
			for(int j = 0; j<arr2[i].length; j++) {
				System.out.print(arr2[i][j]+" ");
			}
			System.out.println();
		}
		
		}
	
	public void practice5() {
		//2차원 배열의 행과 열의 크기를 사용자에게 직접 입력받되, 1~10사이 숫자가 아니면
		//“반드시 1~10 사이의 정수를 입력해야 합니다.” 출력 후 다시 정수를 받게 하세요.
		//크기가 정해진 이차원 배열 안에는 영어 대문자가 랜덤으로 들어가게 한 뒤 출력하세요.
		//(char형은 숫자를 더해서 문자를 표현할 수 있고 65는 A를 나타냄)
		
		
		System.out.print("행 크기: ");
		int num1 = sc.nextInt();
		System.out.print("열 크기: ");
		int num2 = sc.nextInt();
		
		if(num1 < 0 || num1 > 10 && num1 < 0 || num2 > 10) {
			System.out.println("반드시 1~10 사이의 정수를 입력해야 합니다. ");
			practice5();
			return;
	
		}
		
		char [][] arr = new char [num1][num2];
		
		for (int i = 0; i<arr.length; i++) {
			for (int j = 0; j<arr[i].length; j++) {
				arr[i][j] = (char)((Math.random() * 26) + 'A');
		    
		   
		}
				
			}
		for(int i = 0; i<arr.length; i++) {
			System.out.println(Arrays.toString(arr[i]));
		}
		
		
		
		
		//선생님이 만드신 거
		/*
		System.out.println("열 크기: ");
		int row = sc.nextInt();
		System.out.println("행 크기: ");
		int col = sc.nextInt();
		
		if(!( 1 <= row && row <= 10 && 1 <= col && col <= 10));{
			System.out.println("반드시 1~10 사이의 정수를 입력해야 합니다.");
			practice5();
			return;
		}
		
		char [][] arr = new char[row][col];
		for(int i = 0; i<arr.length; i++) {
			for(int j =0; j<arr[i].length; j++) {
				arr[i][j] = (char)(Math.random() * 26 + 65);
				System.out.println(arr[i][j] + " ");
				}
			System.out.println();
		}
		
		
		*/
	}
	
	public void practice6() {
		String[][] strArr = new String[][] {{"이", "까", "왔", "앞", "힘"}, 
									    	{"차", "지", "습", "으","냅"},
									    	{"원","열", "니", "로", "시"}, 
									    	{"배", "심", "다", "좀", "다"}, 
									    	{"열", "히", "! ", "더", "!! "}};
        for(int i = 0; i<strArr.length; i++) {
        
        	for(int j = 0; j<strArr[i].length; j++) {
        		System.out.print(strArr[i][j]+" ");
        		
        	} 
        	// 0, 0 -> 0, 1 -> 0,2
        	// 0,0 -> 1,0 -> 2 , 0
        	
        	System.out.println();
        }
									
		
		
	}
	
	

		
		
		
}