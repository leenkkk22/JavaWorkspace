package com.kh.Array;

public class Run {
	public static void main(String[] args) {
		//A_Array aa = new A_Array();
		//aa.method7();
		
		//B_ArrayCopy ac = new B_ArrayCopy();
		//ac.method5();
		
		C_DemensionalArray cda = new C_DemensionalArray();
		cda.method4();
		
	}

}
