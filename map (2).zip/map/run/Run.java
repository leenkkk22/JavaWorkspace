package com.kh.practice.map.run;

public class Run {
	public static void main(String[] args) {
		
	}
}
